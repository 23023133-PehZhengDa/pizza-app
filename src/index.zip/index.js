import React from "react";
import ReactDOM from "react-dom/client";

function Header() {
    return <h1>Peh Zheng Da's Pizza Co.</h1>
}

function Pizza({ image, name, ingredients, price }) {
    return (
      <div>
        <img src={image} alt={name} />
        <h2>{name}</h2>
        <p>{ingredients}</p>
        <p>${price}</p>
      </div>
    );
  }
  
  function App() {
    return (
      <div>
        <Pizza
          image="pizzas/spinaci.jpg"
          name="Pizza Spinaci"
          ingredients="Tomato, mozarella, spinach, and ricotta cheese"
          price={10}
        />
        <Pizza
          image="pizzas/margherita.jpg"
          name="Pizza Margherita"
          ingredients="Tomato, mozarella, and basil"
          price={8}
        />
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);